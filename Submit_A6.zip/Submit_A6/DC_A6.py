#-------------------------------------------------#
# Title: Assignmnet 5 Homework
# Dev:   Daniel Carrasco
#-------------------------------------------------#

file = open("ToDo.txt","r")
strData = ""
dicRow = {}
lstTable = []
count = -1
count2 = -1 #I may be able to do this with one counter , so will come back to this when time is available

for row in file:
    task,priority = row.strip().split(',')  #strip helped with formatting and split splits row in two variables, Priority and Task when python find a comma. Strip helped with formatting
    dicRow = {task:priority}
    lstTable.append(dicRow)
    count = count + 1
file.close



#Define Class
class A6(object):

    def C1():
        print("Showing the current Items in table '\n' ")
        print(lstTable)
    def C2():
        newRow = {}
        newRow = {newTask: newPriority} # new dictionary
        lstTable.append(newRow) #adding new dictionary to existing table
        print(lstTable)
    def C3():
        del lstTable[int(remove)] #deletes desired row numner
        print(lstTable)
    def C4():
        file = open('ToDo.txt','w')
        for rows in lstTable:
            readline = rows.items()
            for key,value in readline:
                print(key +","+ value + "\n")
                file.write(key + ","+ value+"\n")
        file.close()



#Call Funtions
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line
    if (strChoice.strip()=='1'):
        A6.C1()
        continue
    elif(strChoice.strip() == '2'):
        newTask = input("Enter new Task")
        newPriority = input("Set Priority of new task (high or low") # Can add if loop for error handling
        count = count+1 #counter for row numbers
        print("Here is the updated list list '\n' ")
        A6.C2()
    elif(strChoice == '3'):
        print(lstTable) #show user existing table
        for rows in lstTable:
            count2 = count2 + 1 #to count number of rows
            print('\n' + str(count2) + "  " + str(rows)) #displays row # and contents
        remove =input("Which task # do you want to delete?")
        A6.C3()
        count2 = -1  # this resets the counter so you don't call an out of range index
    elif(strChoice == '4'):
        A6.C4()
    elif (strChoice == '5'):
        break #and Exit the program
